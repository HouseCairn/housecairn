HouseCairn export of one home
==============================

manifest.json   format "housecairn-export", version 4: what the archive holds, with the
                SHA-256 digest and the size of every other file.
data/<app>.json the data of the home, one JSON document per part of the application.
files/          the files of the home, at the paths the documents give.

The format is described in the documentation: Administration > Export and deletion.
This archive holds the home it was made for and nothing of any other home. A HouseCairn
instance restores it as a new home: Homes > Restore a home.
